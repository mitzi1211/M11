/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalfinal;


import javax.swing.JTable;


public class borrowclass {
    
    public borrowclass(){
       
        bookno[0] = "001";
        books[1] = "Pride and Prejudice";
        author[2] = " Jane Austen";
        bookno[1] = "002";
        books[1] = "To Kill a Mockingbird ";
        author[1] = " Harper Lee ";
        bookno[2] = "003";
        books[2] = " The Great Gatsby ";
        author[2] = " F. Scott Fitzgerald";
        bookno[3] = "004";
        books[3] = "One Hundred Years of Solitude";
        author[3] = "Gabriel García Márquez ";
        bookno[4] = "005";
        books[4] = "Song of Solomon";
        author[4] = " Toni Morrison";
        bookno[5] = "006";
        books[5] = "The Shadow of the Wind";
        author[5] = "Carlos Ruiz Zafon";
        bookno[6] = "007";
        books[6] = " Hamlet";
        author[6] = "William Shakespeare";
        bookno[7] = "008";
        books[7] = " The Divine Comedy ";
        author[7] = "Dante Alighieri";
        bookno[8] = "009";
        books[8] = "Alice's Adventures in Wonderland ";
        author[8] = "Lewis Carroll";
        bookno[9] = "010";
        books[9] = "Heart of Darkness";
        author[9] = "Joseph Conrad";
        
     
    }
    public static String[] bookno = new String[40];
    public static String[] books = new String[40];
    public static String[] author = new String[40];
    
      public static void tableAdd(JTable table) {
        try {
            for (int x = 0; x < bookno.length; x++) {
                table.setValueAt(bookno[x], x, 0);
                table.setValueAt(books[x], x, 1);
                table.setValueAt(author[x], x, 2);

            }

        } catch (Exception e) {

        }
}
}
