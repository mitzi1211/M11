/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalfinal;

/**
 *
 * @author asus
 */
public class splashclass {

    public static void main(String[] args) {
        splash n = new splash();
        n.setVisible(true);
        login l = new login();
        try {
            for (int i = 0; i <= 100; i++) {
                Thread.sleep(10);
                splash.a.setText(Integer.toString(i) + "%");
                splash.b.setValue(i);
                if (i == 100) {

                    n.setVisible(false);
                    l.setVisible(true);
                }
            }

        } catch (Exception e) {
        }
    }
}
